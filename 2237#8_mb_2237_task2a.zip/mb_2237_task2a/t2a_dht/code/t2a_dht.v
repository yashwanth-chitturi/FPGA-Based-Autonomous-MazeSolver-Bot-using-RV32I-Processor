
module t2a_dht(
    input clk_50M,
    input reset,
    inout sensor,
    output reg [7:0] T_integral,
    output reg [7:0] RH_integral,
    output reg [7:0] T_decimal,
    output reg [7:0] RH_decimal,
    output reg [7:0] Checksum,
    output reg data_valid
);

    initial begin
        T_integral = 0;
        RH_integral = 0;
        T_decimal = 0;
        RH_decimal = 0;
        Checksum = 0;
        data_valid = 0;
    end
//////////////////DO NOT MAKE ANY CHANGES ABOVE THIS LINE //////////////////

/*
# Team ID:          < eYRC#2237 >
# Theme:            < Task 2A: Temperature and Humidity Measurement Using DHT11 sensor  >
# Author List:      < yashwanth and nikhil >
# Filename:         < t2a_dth.v >
# File Description: < This Verilog module implements a complete DHT11 sensor interface using an FSM that sends the start signal, 
                      reads 40 data bits by measuring pulse widths, validates the checksum, and outputs temperature and humidity values. >
# Global variables: < clk_50M, reset, sensor,T_integral, RH_integral, T_decimal, RH_decimal, Checksum, data_valid,state,
                      co, bit_co, high_duration, data_buffer,sensor_dir, sensor_out, sensor_in >
*/


/*
Summary of logic 

1.The controller drives the sensor pin LOW for 18 ms to send the start signal.

2.Then it releases the line (HIGH) for 40 µs and waits for the sensor’s response.

3.The DHT11 responds by pulling the line LOW for ~80 µs and then HIGH for ~80 µs.

4.After this, the sensor sends 40 data bits (5 bytes).

5.Each bit starts with a 50 µs LOW, then a HIGH whose length encodes the bit (short ≈0, long ≈1).

6.The controller measures the HIGH duration using high_duration and converts it to 0/1 using BIT_THRESHOLD.

7.Each received bit is shifted into a 40-bit buffer data_buffer.

8.After all 40 bits, it checks whether the checksum byte equals the sum of the first four bytes.

9.If valid, it updates temperature and humidity registers and asserts data_valid for one cycle.

10.The FSM then returns to IDLE and waits to start the next reading.

*/

// FSM state definitions
localparam IDLE = 4'd0; 
localparam S_L = 4'd1;   // SET_LOW : Drive line LOW for 18 ms
localparam S_H = 4'd2;   // SET_HIGH
localparam W_R_L = 4'd3; // WAIT_RESP_LOW
localparam W_R_H = 4'd4; // WAIT_RESP_HIGH
localparam R_B_L = 4'd5; // READ_BIT_LOW : Sensor drives LOW for 50 µs at each bit start
localparam R_B_H = 4'd6; // READ_BIT_HIGH : Measure HIGH pulse to decode 0 or 1
localparam S_B = 4'd7;   // STORE_BIT
localparam VALIDATE = 4'd8;

reg [3:0] state = IDLE;

reg [19:0] co; // counter
reg [5:0]  bit_co; // bit_counter:counts 40 incoming bits
reg [11:0] high_duration; // Measures length of HIGH pulse
reg [39:0] data_buffer;


// Timing parameters (50 MHz clock)
localparam S_L_C   = 900000; // 18ms, START_LOW_CYCLES
localparam S_H_C  = 2000;   // 40us, START_HIGH_CYCLES
localparam R_L_C    = 4000;   // 80us, RESP_LOW_CYCLES
localparam R_H_C   = 4000;   // 80us, RESP_HIGH_CYCLES
localparam BIT_L_C     = 2498;   // 50us, BIT_LOW_CYCLES
localparam BIT_THRESHOLD      = 2400;   // ~48us

reg sensor_dir;   // 1 = module drives sensor pin; 0 = release (input)
reg sensor_out;   // When driving, determines value on sensor pin
reg sensor_in;   // 0 = line low, 1 = line high

assign sensor = sensor_dir ? sensor_out : 1'bz;


// Main FSM
always @(posedge clk_50M or negedge reset) begin
    sensor_in <= sensor;
    if (!reset) begin
        state         <= IDLE;
        co       <= 0;
        bit_co   <= 0;
        data_buffer   <= 0;
        high_duration <= 0;
        T_integral    <= 0;
        T_decimal     <= 0;
        RH_integral   <= 0;
        RH_decimal    <= 0;
        Checksum      <= 0;
        data_valid    <= 0;
        sensor_dir    <= 0;
        sensor_out    <= 1;
    end else begin
        data_valid <= 0;
        case (state)
        IDLE: begin
            sensor_dir <= 1;   // Drive LOW to start
            sensor_out <= 0;
            co    <= 0;
            state      <= S_L;
        end
        S_L: begin
            if (co < S_L_C) begin
                co <= co + 1;
            end else begin
                sensor_dir <= 0; // Release line (pull-up will bring high)
                co    <= 0;
                state      <= S_H;
            end
        end
        S_H: begin
            if (co < S_H_C) begin
                co <= co + 1;
            end else begin
                co <= 0;
                state   <= W_R_L;
            end
        end
        W_R_L: begin
            if (sensor_in == 0)
            state <= W_R_H;
        end
        W_R_H: begin
            if (sensor_in == 1) 
				state <= R_B_L;                
        end
        R_B_L: begin
            if (sensor_in == 0)
                co <= co + 1;
            else if (co >= BIT_L_C) begin
                co <= 0;
                high_duration <= 0;
                state <= R_B_H;
            end
        end
        R_B_H: begin 
            if (sensor_in == 1)
                high_duration <= high_duration + 1;
            else  
				    state <= S_B ;
		  end
        S_B: begin
            data_buffer <= {data_buffer[38:0], (high_duration > BIT_THRESHOLD)};
            bit_co <= bit_co + 1;
            high_duration <= 0;
            if (bit_co == 39)
                state <= VALIDATE;
            else
                state <= R_B_L;
        end
        VALIDATE: begin           
            if (data_buffer[7:0] == (data_buffer[39:32] + data_buffer[31:24]
                                + data_buffer[23:16] + data_buffer[15:8])) begin
                data_valid <= 1'b1;
					 RH_integral <= data_buffer[39:32];
                RH_decimal  <= data_buffer[31:24];
                T_integral  <= data_buffer[23:16];
                T_decimal   <= data_buffer[15:8];
                Checksum    <= data_buffer[7:0];
                state      <= IDLE;
                bit_co<= 0;
					 end
        end
        endcase
    end
end




//////////////////DO NOT MAKE ANY CHANGES BELOW THIS LINE //////////////////
  
endmodule
