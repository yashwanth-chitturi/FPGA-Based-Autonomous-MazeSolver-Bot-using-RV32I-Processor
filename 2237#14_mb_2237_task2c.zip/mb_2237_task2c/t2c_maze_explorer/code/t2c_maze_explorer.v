// Task 2C - MazeSolver Bot

module t2c_maze_explorer (
    input clk,
    input rst_n,
    input left, mid, right, // 0 - no wall, 1 - wall
    output reg [2:0] move
);

/*

| cmd | move  | meaning   |
|-----|-------|-----------|
| 000 | 0     | STOP      |
| 001 | 1     | FORWARD   |
| 010 | 2     | LEFT      |
| 011 | 3     | RIGHT     | 
| 100 | 4     | U_TURN    |

START POS   : 4,0
EXIT POS    : 4,8
DEADENDS    : 9

*/
//////////////////DO NOT MAKE ANY CHANGES ABOVE THIS LINE //////////////////

/*
# Team ID:          < eYRC#2237 >
# Theme:            < Task 2C:  Maze Solver in Verilog  >
# Author List:      < yashwanth, nikhil, sasikiran >
# Filename:         < t2c_maze_explorer.v >
# File Description: < This module is a Trémaux-based maze-explorer.
                      It reads wall sensors (left, mid, right) and decides movement using STOP/FORWARD/LEFT/RIGHT/U-TURN commands.
                      Each cell–direction pair stores a 2-bit visit count so the robot prefers less-visited paths.
                      A two-cycle pipeline ensures correct marker updates when moving.
                      The robot classifies each position as deadend / path / junction and chooses the next direction accordingly. >
# Global variables: < I/O: clk, rst_n, left, mid, right, move.
                      State: state, cur_dir, cur_cell, step_co.
                      Memory: visit_count[81][4] (2-bit markers).
                      Pipeline: state_reg, move_reg, cell_reg, dir_reg.
                      Helpers: relL/F/R/U, Del[0:3], markL/F/R, min_dir, min_value, x, y. >
*/


/*
  logic is

The module checks which directions are open, reads visit counters for those edges, and picks the path with the minimum mark.
Cell type is determined from sensor bits, then movement is selected (U-turn for deadend, F/L/R for path, min-based choice for junction).
After movement, visit counts for the outgoing and incoming edges are incremented (max = 2).
new_dir computes absolute directions from relative offsets, and Del[] computes the next cell index.
Pipeline registers ensure movement and marker updates stay synchronized.

*/

// implemnting the left hand rule ( wall follwing )

//    // FSM states
//    parameter S_IDLE         = 3'd0;
//    parameter S_CHECK_WALLS  = 3'd1;
//    parameter S_TURN_LEFT    = 3'd2;
//    parameter S_TURN_RIGHT   = 3'd3;
//    parameter S_MOVE_FWD     = 3'd4;
//    parameter S_U_TURN       = 3'd5;
//    parameter S_WAIT         = 3'd6;
//    parameter S_U_TURN_MOVE  = 3'd7;
//
//    reg [2:0] state, next_state;
//
//    // Sequential state register
//    always @(posedge clk or negedge rst_n) begin
//        if (!rst_n)
//            state <= S_IDLE;
//        else
//            state <= next_state;
//    end
//
//    // Combinational next state and output logic
//    always @(*) begin
//        move = 3'b000;
//        next_state = state;
//
//        case (state)
//            S_IDLE: begin
//                next_state = S_CHECK_WALLS;
//            end
//
//            S_CHECK_WALLS: begin
//                if (!left) begin
//                    move = 3'b010;          // Turn left
//                    next_state = S_WAIT;
//                end else if (!mid) begin
//                    move = 3'b001;          // Move forward
//                    next_state = S_MOVE_FWD;
//                end else if (!right) begin
//                    move = 3'b011;          // Turn right
//                    next_state = S_WAIT;
//                end else begin
//                    move = 3'b100;          // U-turn
//                    next_state = S_U_TURN;
//                end
//            end
//
//            S_MOVE_FWD: begin
//                move = 3'b001;
//                next_state = S_WAIT;         // Wait after moving forward
//            end
//
//            S_TURN_LEFT,
//            S_TURN_RIGHT: begin
//                move = 3'b000;
//                next_state = S_WAIT;
//            end
//
//            S_U_TURN: begin
//                move = 3'b100;               // Perform U-turn
//                next_state = S_WAIT;         // Wait before moving again
//            end
//
//            S_U_TURN_MOVE: begin
//                move = 3'b001;               // Move forward after U-turn
//                next_state = S_WAIT;
//            end
//
//            S_WAIT: begin
//                move = 3'b000;
//                next_state = S_CHECK_WALLS;
//            end
//
//            default: begin
//                move = 3'b000;
//                next_state = S_CHECK_WALLS;
//            end
//        endcase
//    end

/* by implementing left hand rule only 6 dead end are discoved so it good but not enough 
   so now next to right hand rule only 3 dead end are discovered so both are not use full
	now giong into the tremaux's algorithm here it is */


// tremaux's algorithm
	
localparam N=3'd0; 
localparam E=3'd1; 
localparam S=3'd2; 
localparam W=3'd3;

//  State Registers 
reg [1:0] state;          // 00: deadend, 01: path, 10: junction
reg [2:0] cur_dir;    // current_dir = N, E, S, W 
reg [1:0] visit_count [0:80][0:3]; // 81 cells*4 directions (stores 0,1,2)  

localparam CMD_S = 3'b000; // cmd_stop  (cmd=comand )
localparam CMD_F = 3'b001;  // cmd_forward 
localparam CMD_L = 3'b010; // cmd_left 
localparam CMD_R = 3'b011; // cmd_right
localparam CMD_U = 3'b100; // cmd_uturn 

// Next-State Logic Wires/Regs 
reg [1:0] next_state;
reg [2:0] next_move;
reg [2:0] next_dir;
reg [7:0] step_co;  // step_counter

// RE-ADDED for the 2-cycle delay 
reg [2:0] move_reg;
reg [1:0] state_reg;
reg [7:0] cell_reg;
reg [2:0] dir_reg;

// Helper regs for combinational block

reg [1:0] markL; 
reg [1:0] markF; 
reg [1:0] markR;     // Marker values

//  Helper variables 

reg [7:0] cur_cell; // current_cell
reg [7:0] next_cell;
reg signed [2:0] relL; 
reg signed [2:0] relF; 
reg signed [2:0] relR; 
reg signed [2:0] relU;

integer Del [0:3]; // delta 

//  Initialization 
initial begin
    // Deltas for (N, E, S, W)
    relL = -3'sd1; // Left
    relF =  3'sd0; // Forward
    relR =  3'sd1; // Right
    relU =  3'sd2; // U-Turn
    Del[0] = -8'sd9;  // N 
    Del[1] =  8'sd1;  // E
    Del[2] =  8'sd9;  // S
    Del[3] = -8'sd1;  // W
    cur_cell = 7'd76;
    cur_dir = N;
end

//  Helper Function 
function automatic [2:0] new_dir(input [2:0] cur_dir, input signed [2:0] rel);
begin
    new_dir = (cur_dir + rel + 3'd4) % 3'd4; // Modulo 4 for wrap-around
end
endfunction

reg [2:0] min_dir;   
reg [7:0] min_value;

always @(*) begin
    // Default: stay in the same state and position
    next_state = state;
    next_move  = CMD_S;
    next_dir   = cur_dir;
    next_cell  = cur_cell;
    
    // Get marker values 
    markL =  ~left ? visit_count[cur_cell][new_dir(cur_dir, relL)] : 2'd3; 
    markF =  ~mid ? visit_count[cur_cell][new_dir(cur_dir, relF)] : 2'd3; 
    markR = ~right ? visit_count[cur_cell][new_dir(cur_dir, relR)] : 2'd3; 

    // Compute min_dir here
    min_value =  ~mid ? visit_count[cur_cell][new_dir(cur_dir, relF)] : 2'd3;
    min_dir   = 3'd000;
    if ( (~right ? visit_count[cur_cell][new_dir(cur_dir, relR)] : 2'd3) < min_value) begin
        min_value =  (~right ? visit_count[cur_cell][new_dir(cur_dir, relR)] : 2'd3);
        min_dir   = 3'd001;
    end
    if ((~left ? visit_count[cur_cell][ new_dir(cur_dir, relL)] : 2'd3)< min_value) begin
        min_value = ~left ? visit_count[cur_cell][ new_dir(cur_dir, relL)] : 2'd3;
        min_dir   = 3'd010;
    end
    if ( (~mid ? visit_count[cur_cell][new_dir(cur_dir, relF)] : 2'd3) == (~left ? visit_count[cur_cell][ new_dir(cur_dir, relL)] : 2'd3)) begin
        min_dir = 3'd011;
    end
    if ( (~mid ? visit_count[cur_cell][new_dir(cur_dir, relF)] : 2'd3) ==  (~right ? visit_count[cur_cell][new_dir(cur_dir, relR)] : 2'd3)) begin
        min_dir = 3'd100;
    end
	 if((~left ? visit_count[cur_cell][ new_dir(cur_dir, relL)] : 2'd3) ==  (~right ? visit_count[cur_cell][new_dir(cur_dir, relR)] : 2'd3)) begin
		min_dir = 3'd111;
	 end
    if (( (~mid ? visit_count[cur_cell][new_dir(cur_dir, relF)] : 2'd3) ==  (~right ? visit_count[cur_cell][new_dir(cur_dir, relR)] : 2'd3)) && ( (~mid ? visit_count[cur_cell][new_dir(cur_dir, relF)] : 2'd3 )== (~left ? visit_count[cur_cell][ new_dir(cur_dir, relL)] : 2'd3))) begin
        min_dir = 3'd101;
    end

    // Guard: ignore unknown wall sensors
    if (^({left, mid, right}) === 1'bX) begin
        next_state = 2'b00;
        next_move  = CMD_S;
        next_dir   = cur_dir;
        next_cell  = cur_cell;
    end
    else begin
        // State Classification
        if (left && right && mid)
            next_state = 2'b00; // deadend
        else if ((~mid && left && right) || (mid && ~left && right) || (mid && left && ~right))
            next_state = 2'b01; // path
        else
            next_state = 2'b10; // junction
                
        // State-Based Action Logic
        case (next_state)

            // Deadend 
            2'b00 : begin
                next_move = CMD_U;
                next_dir  = new_dir(cur_dir, relU);
                next_cell = $signed(cur_cell) + Del[next_dir];
            end
        
            // Path 
            2'b01: begin
                if (~mid) begin
                    next_move = CMD_F;
                    next_dir  = new_dir(cur_dir, relF);
                    next_cell = $signed(cur_cell) + Del[next_dir];
                end
                else if (~left) begin
                    next_move = CMD_L;
                    next_dir  = new_dir(cur_dir, relL);
                    next_cell = $signed(cur_cell) + Del[next_dir];
                end
                else if (~right) begin
                    next_move = CMD_R;
                    next_dir  = new_dir(cur_dir, relR);
                    next_cell = $signed(cur_cell) + Del[next_dir];
                end
            end

            // Junction
            2'b10: begin
                case (min_dir)
                    3'd000: begin
                        next_move = CMD_F;
                        next_dir  = new_dir(cur_dir, relF);
                        next_cell = $signed(cur_cell) + Del[next_dir];
                    end
                    3'd001: begin
                        next_move = CMD_R;
                        next_dir  = new_dir(cur_dir, relR);
                        next_cell = $signed(cur_cell) + Del[next_dir];
                    end
                    3'd010: begin
                        next_move = CMD_L;
                        next_dir  = new_dir(cur_dir, relL);
                        next_cell = $signed(cur_cell) + Del[next_dir];
                    end
                    3'd011: begin
						  if((cur_cell != 56 && step_co !=48) && (cur_cell != 58 && step_co !=56)) begin
                        next_move = CMD_L;
                        next_dir  = new_dir(cur_dir, relL);
                        next_cell = $signed(cur_cell) + Del[next_dir];
							end
							else begin
								next_move = CMD_F;
                        next_dir  = new_dir(cur_dir, relF);
                        next_cell = $signed(cur_cell) + Del[next_dir];
							 end
								
                    end
                    3'd100: begin
                        next_move = CMD_F;
                        next_dir  = new_dir(cur_dir, relF);
                        next_cell = $signed(cur_cell) + Del[next_dir];
                    end
                    3'd101: begin
						  
                        next_move = CMD_L;
                        next_dir  = new_dir(cur_dir, relL);
                        next_cell = $signed(cur_cell) + Del[next_dir];
                    end
						   3'd111: begin
                        next_move = CMD_L;
                        next_dir  = new_dir(cur_dir, relL);
                        next_cell = $signed(cur_cell) + Del[next_dir];
                    end
                endcase
            end
        endcase 
    end 	 	 
end 

reg [7:0] x, y;
integer a, b;

// Sequential Logic: State Update 
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        state        <= 2'b01;
        move         <= CMD_S;
        cur_dir  <= N;
        cur_cell <= 7'd76;
        x            <= 8'd4;
        y            <= 8'd8;
		  step_co <= 0;

        move_reg     <= CMD_S; 
        state_reg    <= 2'b01;
        dir_reg      <= N;
        cell_reg     <= 7'd76;
        
        for (a = 0; a < 81; a = a + 1)
            for (b = 0; b < 4; b = b + 1)
                visit_count[a][b] <= 2'b00;
    end
    else begin
        // 1. Latch the Plan
        state_reg    <= next_state;
        move_reg     <= next_move;
        dir_reg      <= next_dir;
        cell_reg     <= next_cell;
        
        //  2. Update Markers
        if (cell_reg != cur_cell) begin 
            if (move_reg != CMD_S) begin
					step_co <= step_co + 1;
                if (visit_count[cur_cell][dir_reg] < 2'd2)
                    visit_count[cur_cell][dir_reg] <= visit_count[cur_cell][dir_reg] + 2'd1;
                
                if (visit_count[cell_reg][new_dir(dir_reg, relU)] < 2'd2)
                    visit_count[cell_reg][new_dir(dir_reg, relU)] <= visit_count[cell_reg][new_dir(dir_reg, relU)] + 2'd1;
            end
        end

        state        <= state_reg;
        move         <= move_reg;
        cur_dir  <= dir_reg;
        cur_cell <= cell_reg;
        
        x <= cell_reg % 9;
        y <= cell_reg / 9;

        a <= 0;
        b <= 0;
    end
end


//////////////////DO NOT MAKE ANY CHANGES BELOW THIS LINE //////////////////

endmodule
