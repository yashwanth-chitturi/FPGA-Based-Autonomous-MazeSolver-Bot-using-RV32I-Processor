module uart_rx(
    input clk_3125,
    input rx,
    output reg [7:0] rx_msg,
    output reg rx_parity,
    output reg rx_complete
);

// State definitions
localparam IDLE = 2'b01;
localparam RECEIVE = 2'b10;

reg [1:0] state = IDLE;
reg [8:0] bit_cycle_count = 0; // Changed to 9-bit for 297 cycles
reg [7:0] data_reg = 0;
reg parity_reg = 0;
reg [1:0] stop_reg = 1;
reg [1:0] start_reg = 0;

initial begin
    rx_msg = 8'h00;
    rx_parity = 1'b0;
    rx_complete = 1'b0;
end

always @(posedge clk_3125) begin
    case (state)

        IDLE: begin
            rx_complete <= 1'b0;
            
            // Wait for start bit (falling edge)
            if (rx == 1'b0) begin
                state <= RECEIVE;
                data_reg <= 8'h00;
            end
        end
        
        RECEIVE: begin
            bit_cycle_count <= bit_cycle_count + 1;
            
            // Sample at specific cycles (middle of each 27-cycle bit)
            case (bit_cycle_count)
                9'd14:  if (stop_reg) begin 		// proper Start bit verified
									start_reg <= 1;
								end else start_reg <= 0;
                9'd41:  data_reg[7] <= rx; // LSB
                9'd68:  data_reg[6] <= rx;
                9'd95:  data_reg[5] <= rx;
                9'd122: data_reg[4] <= rx;
                9'd149: data_reg[3] <= rx;
                9'd176: data_reg[2] <= rx;
                9'd203: data_reg[1] <= rx;
                9'd230: data_reg[0] <= rx; // MSB
                9'd257: parity_reg  <= rx;
                9'd284: stop_reg    <= rx;
            endcase
            
            // Complete frame after 297 cycles
            // Note: This check passes on the 298th clock cycle, matching the testbench
            if (bit_cycle_count == 9'd296) begin
                
                // Set complete high, regardless of errors (as per testbench)
					 bit_cycle_count<=1;
					 if(start_reg == 1)	begin
						rx_complete <= 1'b1;
						end else rx_complete <= 1'b0;

                // Validate frame and set outputs
                if (stop_reg == 1'b1) begin  // Valid stop bit
                    rx_parity <= parity_reg;
                    
                    // Check parity: XOR of all data bits should equal parity bit
                    if (parity_reg == (^data_reg)) begin
                        rx_msg <= data_reg;  // Parity correct
								end else begin
                        rx_msg <= 8'h3F;   // Parity error - output '?'
                    end
                end else begin  // Framing error (stop bit not high)
                    rx_msg <= 8'h00;      // Framing error - output '0'
                    rx_parity <= parity_reg;
						  
                end
                
                state <= IDLE;
            end else begin
                rx_complete <= 1'b0;
            end
        end
        
        default: begin
            state <= IDLE;
        end
    endcase
end

endmodule