/*
Module UART Transmitter

Input:   clk_3125 - 3125 KHz clock
         parity_type - even(0)/odd(1) parity type
         tx_start - signal to start the communication.
         data    - 8-bit data line to transmit

Output:  tx      - UART Transmission Line
         tx_done - message transmitted flag


         Baudrate : 115200 bps
*/

// module declaration
module uart_tx(
    input clk_3125,
    input parity_type,tx_start,
    input [7:0] data,
    output reg tx, tx_done
);

initial begin
    tx = 1'b1;
    tx_done = 1'b0;
end
//////////////////DO NOT MAKE ANY CHANGES ABOVE THIS LINE//////////////////
 
 /* Add your logic here */

reg parity_bit;           // running parity
reg tx_value;             // next TX output
reg [2:0] parity_state;   // selects which data bit updates parity
reg [3:0] state = 0;   // 0 → idle, 1–11 → sending bits
reg [5:0] clk = 0;   // divides 3.125 MHz to 115200 baud


always @(posedge clk_3125) begin
    if (state == 0) clk <= 0;              // reset during idle
    else if (clk == 5'd26) clk <= 0;       // reset after each bit
    else clk <= clk + 1;
end

/* TX value selection and data/parity mapping */
always @(*) begin
    tx_value = 1'b1;       // default line high
    parity_state = 3'b111; // default (no parity update)

    if (state == 0)  tx_value = 1'b1; // idle
       
    else if (state >= 1 && state <= 8) begin
        tx_value = data[8 - state];  // send data bits
	 if (state <= 7)
        parity_state = state[2:0];   // update running parity
	 end

    else if (state == 9) tx_value = parity_bit;              // parity bit
    else if (state == 10 || state == 11) tx_value = 1'b1;    // stop bits
end


/* Main state machine */
always @(posedge clk_3125) begin
    tx_done <= 1'b0;       // default low
	 
	if (state == 0) begin   // idle
      tx <= 1'b1;
   if (tx_start) begin     // start bit
       parity_bit <= parity_type ^ data[0];
       tx <= 1'b0; 
       state <= 1; 
        end
    end
	 
   else if (clk == 5'd26) begin  // on each baud tick
         tx <= tx_value;
       
        if (parity_state != 3'b111)  parity_bit <= parity_bit ^ data[parity_state];
        if (state == 11) state <= 0;  // end of frame
        else state <= state + 1;
    end
    else if (state == 11 && clk == 5'd25) tx_done <= 1'b1;   // pulse just before final tick
    else if (state == 11 && clk == 5'd26) tx_done <= 1'b0;
 end
//////////////////DO NOT MAKE ANY CHANGES BELOW THIS LINE//////////////////

endmodule
