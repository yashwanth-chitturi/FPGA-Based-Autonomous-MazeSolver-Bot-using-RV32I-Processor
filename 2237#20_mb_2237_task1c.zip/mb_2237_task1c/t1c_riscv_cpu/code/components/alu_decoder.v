
// alu_decoder.v - logic for ALU decoder

module alu_decoder (
    input            opb5, opb4,
    input [2:0]      funct3,
    input            funct7b5,
	 input [1:0]      ALUOp,
    
	 output reg [3:0] ALUControl
);
always @(*) begin
    if (ALUOp == 2'b00)
        ALUControl = 4'b0000;  // add
    else if (ALUOp == 2'b01)
        ALUControl = 4'b0001;  // sub
    else if (ALUOp == 2'b11)
        ALUControl = 4'b1011;  // unsigned sub
    else begin
        case(funct3)
            3'b000: ALUControl = (funct7b5 & opb5) ? 4'b0001 : 4'b0000; // sub or add
				3'b001: ALUControl = 4'b1001; // sll,slli
            3'b010: ALUControl = 4'b0010; // slt,slti
				3'b011: ALUControl = 4'b1010; // sltu,sltiu
				3'b100: ALUControl = 4'b0101; // xor,xori
				3'b101: ALUControl = (funct7b5 & opb4) ? 4'b0111 : 4'b1000; // srl,sra,srli,srai
            3'b110: ALUControl = 4'b0011; // or,ori
            3'b111: ALUControl = 4'b0100; // and,andi
            default: ALUControl = 4'b0000;
        endcase
    end
end


endmodule


